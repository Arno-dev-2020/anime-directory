import React from 'react';
import { ChevronLeft, ChevronRight } from 'lucide-react';
import { Anime } from '../types';

interface AnimeGridProps {
  animeList: Anime[];
}

const AnimeGrid: React.FC<AnimeGridProps> = ({ animeList }) => {
  const scrollContainer = (direction: 'left' | 'right') => {
    const container = document.getElementById('anime-scroll-container');
    if (container) {
      const scrollAmount = direction === 'left' ? -container.clientWidth : container.clientWidth;
      container.scrollBy({ left: scrollAmount, behavior: 'smooth' });
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
      <h2 className="text-2xl font-bold text-white mb-8">Popular Anime</h2>
      
      <div className="relative group">
        <button 
          onClick={() => scrollContainer('left')}
          className="absolute left-0 top-1/2 -translate-y-1/2 z-10 bg-black/50 p-2 rounded-full text-white opacity-0 group-hover:opacity-100 transition-opacity -translate-x-1/2 hover:bg-black/70"
        >
          <ChevronLeft className="w-6 h-6" />
        </button>

        <div 
          id="anime-scroll-container"
          className="flex overflow-x-auto space-x-6 scrollbar-hide scroll-smooth"
          style={{ scrollbarWidth: 'none', msOverflowStyle: 'none' }}
        >
          {animeList.map((anime) => (
            <div
              key={anime.id}
              className="flex-none w-[250px] group cursor-pointer transition-transform duration-300 hover:scale-105"
            >
              <div className="relative aspect-[2/3]">
                <img
                  src={anime.coverImage}
                  alt={anime.title}
                  className="w-full h-full object-cover rounded-lg"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/40 to-transparent rounded-lg opacity-0 group-hover:opacity-100 transition-opacity">
                  <div className="absolute bottom-0 p-4">
                    <h3 className="text-lg font-semibold text-white">{anime.title}</h3>
                    <div className="flex items-center mt-2">
                      <span className="text-yellow-400 font-bold">{anime.rating}</span>
                      <span className="text-gray-400 ml-1">/ 10</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>

        <button 
          onClick={() => scrollContainer('right')}
          className="absolute right-0 top-1/2 -translate-y-1/2 z-10 bg-black/50 p-2 rounded-full text-white opacity-0 group-hover:opacity-100 transition-opacity translate-x-1/2 hover:bg-black/70"
        >
          <ChevronRight className="w-6 h-6" />
        </button>
      </div>
    </div>
  );
};

export default AnimeGrid;