import React from 'react';
import { Play } from 'lucide-react';
import { HeroAnime } from '../types';

interface HeroProps {
  anime: HeroAnime;
}

const Hero: React.FC<HeroProps> = ({ anime }) => {
  return (
    <div className="relative h-[80vh] w-full">
      <div className="absolute inset-0">
        <img
          src={anime.heroImage}
          alt={anime.title}
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black via-black/50 to-transparent" />
      </div>
      
      <div className="relative h-full max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex items-center">
        <div className="max-w-2xl">
          <h1 className="text-4xl sm:text-5xl md:text-6xl font-bold text-white mb-4">
            {anime.title}
          </h1>
          <p className="text-lg text-gray-300 mb-8">
            {anime.description}
          </p>
          <div className="flex items-center space-x-4">
            <button className="flex items-center px-6 py-3 bg-red-600 text-white rounded-lg hover:bg-red-700 transition">
              <Play className="w-5 h-5 mr-2" />
              Watch Trailer
            </button>
            <div className="flex items-center">
              <span className="text-yellow-400 font-bold text-lg">{anime.rating}</span>
              <span className="text-gray-400 ml-2">/ 10</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Hero;