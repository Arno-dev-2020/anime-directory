import React from 'react';
import Navbar from './components/Navbar';
import Hero from './components/Hero';
import AnimeGrid from './components/AnimeGrid';
import { featuredAnime, animeList } from './data/animeData';

function App() {
  return (
    <div className="min-h-screen bg-black">
      <Navbar />
      <Hero anime={featuredAnime} />
      <AnimeGrid animeList={animeList} />
    </div>
  );
}

export default App;